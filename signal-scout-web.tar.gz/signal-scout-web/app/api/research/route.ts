import { prisma } from "@/lib/prisma";
import { NextRequest } from "next/server";

// GET /api/research — list all sessions
export async function GET() {
  const sessions = await prisma.research.findMany({
    orderBy: { createdAt: "desc" },
  });
  return Response.json(sessions);
}

// POST /api/research — create a new research request
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { topic, budget, userId } = body;

    if (!topic || !budget) {
      return Response.json(
        { error: "topic and budget are required" },
        { status: 400 }
      );
    }

    // Create the research session
    const session = await prisma.research.create({
      data: {
        topic,
        budget: parseFloat(budget),
        status: "pending",
        // For now, use a default user. Replace with real auth later.
        user: {
          connectOrCreate: {
            where: { email: "demo@signalscout.xyz" },
            create: { email: "demo@signalscout.xyz", name: "Demo User" },
          },
        },
      },
    });

    // TODO: Trigger Locus checkout for payment
    // TODO: After payment, notify the OpenClaw agent to start research

    // For now, mark as "running" immediately (skip payment for hackathon demo)
    await prisma.research.update({
      where: { id: session.id },
      data: { status: "running" },
    });

    return Response.json(session, { status: 201 });
  } catch (error) {
    console.error("Failed to create research session:", error);
    return Response.json(
      { error: "Failed to create research session" },
      { status: 500 }
    );
  }
}
